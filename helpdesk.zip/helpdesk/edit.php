<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>
<form action="execeditstatus.php" method="post">
        
	<input type="hidden" name="foodid" class="ed" value="<?php echo $id=$_GET['id'] ?>">
        Enter name of Technician assigned:<br>
        <select name="Technician" class="ed">
 <option value="Kimani Gichia(254710600337)">Kimani Gichia</option>
  <option value="Christopher Maundu(254720618319)">Christopher Maundu</option>
  <option value="Samson Chalo(254722769473)">Samson Chalo</option>
  <option value="Prisilla Kinonga(254757138726)" selected> Prisila Kinonga</option>
  <option value="Benjamin Munguti(254728913842)">Benjamin Munguti</option>
  <option value="Daniel Mule(254731921838)"> DanielMule</option>
  <option value="Cyrus Oyugi(254720062844)">Cyrus Oyugi</option>
  <option value="Nelly Nkonge(254715416545)">Nelly Nyawira</option>
  <option value="Kevin Gichora(254723024148)">Kevin Gichora</option>
  <option value="Dennis Mwendwa(254728265550)">Dennis Mwendwa</option>
  <option value="Wilfred Achachi(254733155870)">Wilfred Achachi</option>
  <option value="Esther Wanjiru(254711540597)">Esther Wanjiku</option>
  <option value="Roy Odendo(254741210685)">Roy Odendo</option>
  <option value="Benson Mukanda(254703704924)">Benson Mukanda</option>
  <option value="Marvin Kabue(254711692201)">Marvin Kabue</option>
  <option value="Irene Mueni(254715244465)">Irene Mueni</option>
  <option value="Shadrack Osama(254708410098)">Shadrack Osama</option>
  <option value="Gilbert Chege(254713224417)">Gilbert Chege</option>
  <option value="Rozmin Rajwani(254733444494)">Rozmin Rajwani</option>
  <option value="Christopher Mulitu(2547200254183)">Christopher Mulitu</option>
  <option value="Dino Anzulovic(254704203670)">Dino Anzulovic</option>
  <option value="Antony Kariuki(2547)">Antony Kariuki</option>
<option value="Naima Hassan(254727756137)">Naima Hassan</option>
  <option value="Sarah Kariuki(254722585631)">Sarah Kariuki</option>
  
	<br>
	<input type="submit" value="Edit" id="button1">
</form>