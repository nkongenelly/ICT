<?php
	include('../store/connect.php');
	$foodid = $_POST['foodid'];
	$type=$_POST['type'];
	$rate=$_POST['rate'];
	$description=$_POST['description'];
	mysql_query("UPDATE internet_shop SET name='$type', price='$rate', description='$description' WHERE id='$foodid'");
	header("location: food.php");
?>