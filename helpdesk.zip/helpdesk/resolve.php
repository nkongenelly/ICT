<?

$jobcard_no  = $_POST["jobcard_no"];
$phoneNumbers= $_POST["phoneNumber"];
$IssueSubject= $_POST["IssueSubject"];
$Company= $_POST["Company"];
$Client= $_POST["Client"];
$Description= $_POST["Description"];
//trim spaces from phone number
$phoneNumber = trim($phoneNumbers);
//Get tech phone number and name separately
$techname = $_POST["Technician"];
$tech1 = explode("(",$techname);
$Technician= $tech1[0];
$tech22 = explode(")",$tech1[1]);
$tech2 = trim($tech22[0]);
echo $tech2[0];

//$tech2 = "+254715416545";
//$phoneNumber = strval($phoneNumbers );
/*$jobcard_no = "jobcard_no";
$phoneNumber = "phoneNumber";
$IssueSubject = "IssueSubject";
$Technician = "Technician";
$Client = "Client";
$tech2 = "tech2";
$Description = "Description";
$Company ="Company";*/

 
         
         $body = array(
           	 "jobcard_no" =>  $jobcard_no,
            	"phoneNumber" =>  $phoneNumber,
            	"IssueSubject" => $IssueSubject
                
             	
            );
        
       //set the url of the webhook to test the curl fuction
           // $url = "https://prod-105.westeurope.logic.azure.com:443/workflows/b0d08b9404bf46d18ff7b926ce659909/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=n73NpzYOjj50Ab9wfFiEqFmdqkFrjEyyrKgZ2U4Lhck"; 
          $url = "https://prod-31.southeastasia.logic.azure.com:443/workflows/c7703c891702485a82fc48f25be3adca/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=snsCQ8m4ePpmxxd9DwZzenvWx8SsXVnrz8jmmA87Z8I";
          
          
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); //Remote Location URL
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Return data instead printing directly in Browser
	    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 7); //Timeout after 7 seconds
	     curl_setopt($ch, CURLOPT_POSTFIELDS, '[' . json_encode($body) . ']');
	      //curl_setopt($ch, CURLOPT_HTTPHEADER, true); 
	    curl_setopt($ch, CURLOPT_HTTPHEADER, array(       // change CURLOPT_HEADER to CURLOPT_HTTPHEADER
	    	"Content-Type:application/json"
	    ));
	       $result = curl_exec($ch);
	    curl_close($ch);
	      
	     echo $ch;
	   
	    header("location: index.php");  
  ?>




