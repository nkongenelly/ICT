<?

//$jobcard_no  = $_POST["jobcard_no"];
//$phoneNumber= $_POST["phoneNumber"];
echo  $_GET["jobcard_no"] ;

?>