<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>
<form action="statusupdate.php" method="post">
        
	<input type="hidden" name="foodid" class="ed" value="<?php echo $id=$_GET['id'] ?>">
	<br>
        Update status:<br>
        <select name="status" class="ed">
 <option value="Delivered">Resolved</option>
  <option value="Pending">Pending</option>
  
  
	<br>
	<input type="submit" value=" Update" id="button1">
</form>