<?php
	//require_once('../auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="refresh" content="30">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin</title>
<link rel="stylesheet" type="text/css" href="css/960.css" />
<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/text.css" />
<link rel="stylesheet" type="text/css" href="css/blue.css" />
<link type="text/css" href="css/smoothness/ui.css" rel="stylesheet" />  
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script>

<script type="text/javascript" src="html2CSV.js" ></script>

<script src="js/application.js" type="text/javascript" charset="utf-8"></script>	
<!--sa poip up-->
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
   <script src="lib/jquery.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      })
    })
  </script>
<script type="text/javascript">
function fnExcelReport()
{
    var tab_text="<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('resultTable'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}



</script>




</head>

<body>
<!-- WRAPPER START -->
<div class="container_16" id="wrapper">	
<!-- HIDDEN COLOR CHANGER -->      
      <div style="position:relative;">
  	<!--LOGO-->
	<div class="grid_8" id="logo"> Kaizala LanSupport</div>
    <div class="grid_8">
<!-- USER TOOLS START -->
     
    </div>
<!-- USER TOOLS END -->    
<div class="grid_16" id="header">
<!-- MENU START -->
<div id="menu">
	<ul class="group" id="menu_group_main">
	<img src="images/ict1.png" width="120" height="100" img align="center"/> 	        
    </ul>
</div>
<!-- MENU END -->
</div>


<!-- CONTENT START -->
    <div class="grid_16" id="content">
    <!--  TITLE START  --> 
    <div class="grid_9">
    
    </div>
    <div class="clear">
    </div>
    <!--  TITLE END  -->    
    <!-- #PORTLETS START -->
    <div id="portlets">
    
	<!--  SECOND SORTABLE COLUMN END -->
    <div class="clear"></div>
    <!--THIS IS A WIDE PORTLET-->
		<div class="portlet">
			<div class="portlet-header fixed"><img src="images/icons/user.jpg" width="16" height="16" alt="Latest Registered Users" /> 
			<label for="filter">Search</label> <input type="text" name="filter" value="" id="filter" />
			&nbsp;&nbsp;Legend:  <img src="cancel.jpeg">Pending &nbsp;<img src="active.png">Resolved 
			</div>
                        
			<table cellpadding="1" cellspacing="1" id="resultTable">
				<thead>
					<tr>
						<th  style="border-left: 1px solid #C1DAD7"> Date  </th>
						<th>Client </th>
						<th>Company </th>
						<th>ServiceIssue </th>
                                                <th>Description </th>
                                                <th>Technician</th>
                                                <th> Jobcard No </th>
                                                <th>User Number </th>
                                                <th>Action</th>
                                            
					</tr>
				</thead>           
				<tbody>
				<?php
					$servername = "localhost";
$username = "ram23306_ta";
$password = "ta.123";
$dbname = "ram23306_helpdesk";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
							$sql = "SELECT Date, Client, Company, ServiceIssue, IssueDescription, id, jobcard_no, phoneNumber, IssueSubject, Technician, Feedback, status FROM Sheet1 ORDER BY 
   id  DESC";
                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                         // output data of each row
                                                          while($row = $result->fetch_assoc()) {
                                                        echo '<tr class="record" id="'.$row['status'].'">';
							
							echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['Date'].'</td>';
							echo '<td>'.$row['Client'].'</td>';
							echo '<td><div align="left">'.$row['Company'].'</div></td>';
							echo '<td><div align="left">'.$row['ServiceIssue'].'</div></td>';
                                                        echo '<td><div align="left">'.$row['IssueDescription'].'</div></td>';
                                                        echo '<td><div align="left">'.$row['Technician'].'</div></td>';
							echo '<td><div align="left">'.$row['jobcard_no'].'</div></td>';
                                                        echo '<td><div align="left">'.$row['phoneNumber'].'</div></td>';
                                                        //echo '<td><div align="left">'.$row['status'].'</div></td>';

							
						
	echo '<td><div align="center"> 		 <a rel="facebox" href="close.php?jobcard_no='.$row['jobcard_no'].'&phoneNumber='.$row['phoneNumber'].'&IssueSubject='.$row['IssueSubject'].'" title="Click To View Booking">Resolve </a> | <a rel="facebox" href="update.php?id='.$row['id'].'">Update</a>
	
	</a></div></td>';
							echo '</tr>';
						    }
} else {
    echo "0 results";
}
$conn->close();

					?> 
				</tbody>
			</table>
<button id="btnExport" onclick="fnExcelReport();"> EXPORT </button>
			</form>
			</div>
		</div>
<!--  END #PORTLETS -->  
   </div>
    <div class="clear"> </div>
<!-- END CONTENT-->    
  </div>
<div class="clear"> </div>

</div>
</div>
<!-- WRAPPER END -->
<!-- FOOTER START -->
<div class="container_16" id="footer">
Website Administration by <a href="../index.htm">ICT Africa</a></div>
<!-- FOOTER END -->
<script src="js/jquery.js"></script>
  <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
 if(confirm("Sure you want to delete this update? There is NO undo!"))
		  {

 $.ajax({
   type: "GET",
   url: "deleteres.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
		.animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
</body>
</html>