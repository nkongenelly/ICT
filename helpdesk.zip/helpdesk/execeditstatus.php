<?php
$servername = "localhost";
$username = "ram23306_ta";
$password = "ta.123";
$dbname = "ram23306_helpdesk";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
   //echo 'Connected successfully<br>';
        $foodid = $_POST['foodid'];
	$jobcard_no=$_POST['jobcard_no'];
        $Technician=$_POST['Technician'];
  $sql="UPDATE Sheet1 SET jobcard_no='$jobcard_no', Technician='$Technician' WHERE id='$foodid'";
  //$sql="UPDATE Sheet1 SET jobcard_no = jobcard_no + '$jobcard_no', Technician='$Technician' WHERE id='$foodid'";
     header("location:index.php"); 
   if (mysqli_query($conn, $sql)) {
      echo "Record updated successfully";
   } else {
      echo "Error updating record: " . mysqli_error($conn);
   }
   mysqli_close($conn);
?>