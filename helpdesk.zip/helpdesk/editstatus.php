<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>
<form action="execeditstatus.php" method="POST">
        
	<input type="hidden" name="foodid" class="ed" value="<?php echo $id=$_GET['id'] ?>">
	Enter the jobcard no:<br>
	<input type="text" name="jobcard_no" class="ed" value="<?php echo $jobcard_no=$_GET['jobcard_no'] ?>" >
	<br>
        Enter name of Technician assigned:<br>
        <select name="Technician" class="ed">
  <option value="Antony Kariuki(254703457031)">Antony Kariuki</option>  
  <option value="Benjamin Munguti(254728913842)">Benjamin Munguti</option>
  <option value="Benson Mukanda(254703704924)">Benson Mukanda</option>
  <option value="Christopher Maundu(254720618319)">Christopher Maundu</option>
  <option value="Christopher Mulitu(2547200254183)">Christopher Mulitu</option>
  <option value="Cyrus Oyugi(254720062844)">Cyrus Oyugi</option>
  <option value="Daniel Mule(254731921838)"> DanielMule</option>
  <option value="Dennis Mwendwa(254728265550)">Dennis Mwendwa</option>
  <option value="Dino Anzulovic(254704203670)">Dino Anzulovic</option>
  <option value="Esther Wanjiku(254711540597)">Esther Wanjiku</option>
  <option value="Gilbert Chege(254713224417)">Gilbert Chege</option>
  <option value="Gloria Nkatha(254711692201)">Gloria Nkatha</option>
  <option value="Irene Mueni(254715244465)">Irene Mueni</option>
  <option value="Kevin Gichora(254723024148)">Kevin Gichora</option>
  <option value="Kimani Gichia(254710600337)">Kimani Gichia</option>
  <option value="Marvin Kabue(254711692201)">Marvin Kabue</option>
  <option value="Mickey Ngure(254705041752)">Mickey Ngure</option>
  <option value="Naima Hassan(254727756137)">Naima Hassan</option>
  <option value="Nelly Nkonge(254715416545)">Nelly Nyawira</option>
  <option value="Philip Mwendwa(254723232563)">Philip Mwendwa</option>
  <option value="Prisilla Kinonga(254757138726)" selected> Prisilla Kinonga</option>
  <option value="Rozmin Rajwani(254733444494)">Rozmin Rajwani</option>
  <option value="Roy Odendo(254741210685)">Roy Odendo</option>
  <option value="Samson Chalo(254722769473)">Samson Chalo</option>
  <option value="Sarah Kariuki(254722585631)">Sarah Kariuki</option> 
  <option value="Shadrack Osama(254708410098)">Shadrack Osama</option>
  <option value="Wilfred Achachi(254733155870)">Wilfred Achachi</option>
  <option value="Intern-Victor(254705069836)">Intern(Victor)</option>
  <option value="Intern-Eugine(254704454416)">Intern(Eugine)</option>
  <option value="Intern-Rono(254700101127)">Intern(Rono)</option>
  <option value="Intern-Jonah(254707238011)">Intern(Jonah)</option>
  
	<br>
	<input type="submit" value="Assign" id="button1">
</form>