<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>
	
		<form action="helpdeskCloseJob.php"  class="ed" method="POST" >
		
                          Jobcard No:
			<input type="text" name="jobcard_no" class="ed" value="<?php echo $jobcard_no=$_GET['jobcard_no'] ?>" >
                          Phone No:
			<input type="text" name="phoneNumber" class="ed" value="<?php echo $phoneNumber=$_GET['phoneNumber'] ?>">
			 Issue Subject:
			<input type="text" name="IssueSubject" class="ed" value="<?php echo $IssueSubject=$_GET['IssueSubject'] ?>"> 

			<button type="submit">Resolve</button>
		</form>
	
