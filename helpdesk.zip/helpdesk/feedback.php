<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>
	
		<form action="#"  class="ed" method="POST" >
		
                          Jobcard No:
			<input type="text" name="jobcard_no" class="ed" value="<?php echo $jobcard_no=$_GET['jobcard_no'] ?>" >
			 Client:
			<input type="text" name="Client" class="ed" value="<?php echo $Client=$_GET['Client'] ?>">
                        Company:
                        <input type="text" name="Company" class="ed" value="<?php echo $Company=$_GET['Company'] ?>">         
                         Feedback:
			<input type="text" name="Feedback" class="ed" value="<?php echo $Feedback=$_GET['Feedback'] ?>">
			
			<button type="submit">Summary</button>
		</form>
	
